package com.rdp.hosptialfrontdesk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalFrontDeskApplicationTests {

	@Test
	void contextLoads() {
	}

}
